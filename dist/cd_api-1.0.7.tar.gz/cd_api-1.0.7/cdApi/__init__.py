from __future__ import absolute_import

name = "rqk_cd_api"
